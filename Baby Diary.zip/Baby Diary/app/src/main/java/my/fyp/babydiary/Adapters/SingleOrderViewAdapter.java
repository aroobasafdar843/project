package my.fyp.babydiary.Adapters;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.squareup.picasso.Picasso;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import my.fyp.babydiary.Activities.OrderHistory;
import my.fyp.babydiary.DataModel.SingleOrderViewModel;
import my.fyp.babydiary.R;


public class SingleOrderViewAdapter extends RecyclerView.Adapter<SingleOrderViewAdapter.RecyclerViewHolder>  {
    Context ctx;
    ArrayList<SingleOrderViewModel> arrayList = new ArrayList<SingleOrderViewModel>();
    RecyclerViewHolder recyclerViewHolder;
    FirebaseUser mCurrentUser;
    DatabaseReference database;
    boolean run=true; //set it to false if you want to stop the timer
    Handler mHandler = new Handler();
    ArrayList<String> productImagesList=new ArrayList<>();

    private SharedPreferences sharedPreferences;
    private String myProfilePrefrence="profilePrefrence";
    private String keyIsLoggedIn="isLoggedIn";
    private String keyUserId="user_id";
    private String keyUserName="name";
    private String keyUserEmail="email";
    private String keyUserPassword="password";
    private String keyUserPhone="phone";
    private String keyUserImage="image";
    private String keyUserRole="userRole";

    public SingleOrderViewAdapter(ArrayList<SingleOrderViewModel> arrayList, Context ctx){

        this.arrayList=arrayList;
        this.ctx=ctx;

    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ordor_history_singleitem, parent, false);

        recyclerViewHolder = new RecyclerViewHolder(view,ctx);

        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(final RecyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        sharedPreferences=ctx.getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);
        final String userRole=sharedPreferences.getString(keyUserRole,"");



        if(position==0){


            holder.cont_l1.setVisibility(View.VISIBLE);
            holder.constraintLayoutOrderTop.setVisibility(View.VISIBLE);
            holder.tvCustomerName.setVisibility(View.GONE);
            holder.tvCustomerPhone.setVisibility(View.GONE);

            if(userRole.equals("admin")) {
                holder.tvCustomerName.setVisibility(View.VISIBLE);
                holder.tvCustomerPhone.setVisibility(View.VISIBLE);
                holder.tvCustomerName.setText("Customer Name : " + arrayList.get(0).getReceiverName());
                holder.tvCustomerPhone.setText("Customer Phone : " + arrayList.get(0).getReceiverPhone());


            }
                holder.tvOrderStatus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(userRole.equals("admin") && holder.tvOrderStatus.getText().equals("Requested")){

                            AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                            builder.setTitle("Order Status Change");
                            builder.setMessage("If You have Accepted Order Click Yes")
                                    .setCancelable(false)
                                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {

                                            UpdateOrderStatusAccepted();
                                            //  UpdateOrderStatusCompleted();
                                            ctx.startActivity(new Intent(ctx, OrderHistory.class));
                                        }
                                    })
                                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            dialog.cancel();
                                        }
                                    });
                            AlertDialog alert = builder.create();
                            alert.show();

                        }else
                            if(holder.tvOrderStatus.getText().equals("Accepted") && userRole.equals("user")){
                                AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                                builder.setTitle("Order Status Change!");
                                builder.setMessage("If You have Received Your Order Status to Received")
                                        .setCancelable(false)
                                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {

                                                UpdateOrderStatusCompleted();
                                                //  UpdateOrderStatusCompleted();
                                                ctx.startActivity(new Intent(ctx, OrderHistory.class));
                                            }
                                        })
                                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.cancel();
                                            }
                                        });
                                AlertDialog alert = builder.create();
                                alert.show();
                            }




                    }
                });


            holder. tvOrderTime.setText("Order Time : "+arrayList.get(0).getOrderTime());
            holder.tvOrderNumber.setText("Order Number : "+arrayList.get(0).getOrderNumber());

            int total_Bill=0;
            for (int i=0;i<arrayList.size();i++){
                total_Bill= total_Bill+Integer.parseInt(arrayList.get(i).getProductPrice().toString());
            }

             holder.tvCustomerAddress.setText("Address : "+arrayList.get(0).getReceiverAddress()+"\n\nTotal Bill : "+total_Bill+" Rs.");


            holder.tvOrderStatus.setText(arrayList.get(0).getOrderStatus());


           final String orderDateTime=arrayList.get(0).getOrderTime().toString();








        }else {
            holder.cont_l1.setVisibility(View.GONE);
            holder.constraintLayoutOrderTop.setVisibility(View.GONE);
        }



        database= FirebaseDatabase.getInstance().getReference().child("Product Images").child(arrayList.get(position).getProductImage());

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                productImagesList.clear();
                for (DataSnapshot childSnapshot1 : snapshot.getChildren()) {

                    String url=childSnapshot1.getValue().toString();
                    productImagesList.add(url);
                    //      Toast.makeText(ctx,"url"+url,Toast.LENGTH_LONG).show();
                }
                for (int i=0;i<productImagesList.size();i++){
                    ImageView imageView=new ImageView(ctx);

                    Picasso.with(ctx).load(productImagesList.get(i)).placeholder(R.drawable.iconaddproduct100).into(imageView);
                    // imageView.setScaleType(ImageView.ScaleType.FIT_XY);
                    holder.ivItemImage.addView(imageView);
                    holder.ivItemImage.setFlipInterval(3000);
                    holder.ivItemImage.setAutoStart(true);
                    holder.ivItemImage.setInAnimation(ctx,android.R.anim.slide_in_left);
                    holder.ivItemImage.setOutAnimation(ctx,android.R.anim.slide_out_right);
                    holder.ivItemImage.startFlipping();


                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });


        holder.tvItemName.setText("Baby Category : "+arrayList.get(position).getBabyCategory()+"\nGarments Category : "+ arrayList.get(position).getGarmentsCategory()+"\nProduct Name : "+arrayList.get(position).getProductName()+"\nProduct Price : "+arrayList.get(position).getProductPrice()+" Rs.");





    }

    private void UpdateOrderStatusAccepted() {

        mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
        final String uId=mCurrentUser.getUid();

        DateFormat df2 = new SimpleDateFormat("hh:mm:ss a dd-MMM-yyyy");
        String date2 = df2.format(Calendar.getInstance().getTime());

        HashMap<String, Object> result = new HashMap<>();
        result.put("orderStatus", "Accepted");


        FirebaseDatabase.getInstance().getReference().child("Orders").child(arrayList.get(0).getReceiverID()).child(arrayList.get(0).getOrderTime()).child("item1").updateChildren(result)

                .addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {

                HashMap<String, Object> result1 = new HashMap<>();
                result1.put("isAvailable", "false");

                FirebaseDatabase.getInstance().getReference().child("Products").child(arrayList.get(0).getBabyCategory()).child(arrayList.get(0).getGarmentsCategory()).child(arrayList.get(0).getProductID()).updateChildren(result1);

                Toast.makeText(ctx,"Order Accepted",Toast.LENGTH_LONG).show();
            }
        });




    }



    private void UpdateOrderStatusCompleted() {
        mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
        final String uId=mCurrentUser.getUid();

        HashMap<String, Object> result = new HashMap<>();
        result.put("orderStatus", "Completed");


        FirebaseDatabase.getInstance().getReference().child("Orders").child(arrayList.get(0).getReceiverID()).child(arrayList.get(0).getOrderTime()).child("item1").updateChildren(result).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(ctx,"Order Completed",Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }



    public static class RecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ViewFlipper ivItemImage;
        TextView cont_l1,tvOrderStatus,tvCustomerName,tvCustomerPhone,tvCustomerAddress,tvOrderTime,tvOrderNumber,tvItemName;
        ConstraintLayout constraintLayoutOrderTop,constraintLayoutOrderBottom;

        Context ctx;
        private RecyclerView recyclerViewHolder;

        @SuppressLint("NewApi")
        public RecyclerViewHolder(View view, Context ctx) {
            super(view);
            view.setOnClickListener(this);
            this.ctx=ctx;
            tvOrderStatus=(TextView) view.findViewById(R.id.tvOrderStatus);
            tvCustomerName=(TextView) view.findViewById(R.id.tvCustomerName);
            tvCustomerPhone=(TextView) view.findViewById(R.id.tvCustomerPhone);
            tvCustomerAddress=(TextView) view.findViewById(R.id.tvAddress);
            tvOrderTime=(TextView) view.findViewById(R.id.tvOrdorTime);
            tvOrderNumber=(TextView) view.findViewById(R.id.tvOrderNumber);
            tvItemName=(TextView) view.findViewById(R.id.tvItemName);
            ivItemImage=(ViewFlipper) view.findViewById(R.id.ivOrderItemImage);


            cont_l1=(TextView) view.findViewById(R.id.cont_l1);
            constraintLayoutOrderTop=(ConstraintLayout) view.findViewById(R.id.constLyaoutOrderTop);
            constraintLayoutOrderBottom=(ConstraintLayout) view.findViewById(R.id.constLyaoutOrderBottom);


        }

        @Override
        public void onClick(View view) {
            int position=getAdapterPosition();


            switch (position){


            }






        }
    }
}

