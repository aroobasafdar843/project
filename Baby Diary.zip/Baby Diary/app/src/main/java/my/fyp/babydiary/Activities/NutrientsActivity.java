package my.fyp.babydiary.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import my.fyp.babydiary.Adapters.NutrientsActivityAdapter;
import my.fyp.babydiary.DataModel.NutrientsDataProvider;
import my.fyp.babydiary.R;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;

public class NutrientsActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    NutrientsActivityAdapter adapter;
    ArrayList<NutrientsDataProvider> arrayList;
    DatabaseReference database;
    ProgressDialog progressDialog;
    FloatingActionButton fabAddNutrients;

    FirebaseUser mCurrentUser;
    Spinner spinnerSelectBaby;
    String selectBaby;

    private SharedPreferences sharedPreferences;
    private String myProfilePrefrence="profilePrefrence";

    private String keyIsLoggedIn="isLoggedIn";
    private String keyFirstName="fName";
    private String keyPhone="phone";
    private String keyLastName="lName";
    private String keyEmail="email";
    private String keyUSerRole="userRole";
    private String keyPassword="password";

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrients);


        sharedPreferences=getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);


        recyclerView=(RecyclerView) findViewById(R.id.rvNutrients);
        fabAddNutrients =(FloatingActionButton) findViewById(R.id.fabAddNutrients);
        spinnerSelectBaby=(Spinner) findViewById(R.id.spBabyCategory);

        fabAddNutrients.setVisibility(View.GONE);

        if(sharedPreferences.getString(keyUSerRole,"").equals("admin")){
            fabAddNutrients.setVisibility(View.VISIBLE);
        }


        fabAddNutrients.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addNutrients();
            }
        });


        arrayList=new ArrayList<NutrientsDataProvider>();


        spinnerSelectBaby.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    selectBaby="";
                }else {
                    selectBaby=spinnerSelectBaby.getItemAtPosition(position).toString();

                    progressDialog=new ProgressDialog(NutrientsActivity.this);
                    progressDialog.setMessage("Loading..");
                    progressDialog.setCancelable(false);
                    progressDialog.show();

                    callFirebase(selectBaby);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });





    }

    private void addNutrients() {

        final String[] babyCategory = new String[1];
        final android.app.AlertDialog.Builder alert=new android.app.AlertDialog.Builder(this);

        LayoutInflater inflater = getLayoutInflater();
        View alertLayout = inflater.inflate(R.layout.add_new_nutrients, null);

        final Spinner spBabyCategory=(Spinner) alertLayout.findViewById(R.id.spBabyCategory);
        final EditText etNutrientsName=(EditText) alertLayout.findViewById(R.id.etNutrientsName);
        final EditText etNutrientDose=(EditText) alertLayout.findViewById(R.id.etNutrientDose);
        final EditText etNutrientsDesc=(EditText) alertLayout.findViewById(R.id.etNutrientsDesc);


        final Button btnAdd=(Button) alertLayout.findViewById(R.id.btnAddMedicen);



        alert.setCancelable(true);
        alert.setView(alertLayout);

        spBabyCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    babyCategory[0] ="";
                }else {
                    babyCategory[0]=spBabyCategory.getItemAtPosition(position).toString();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        final android.app.AlertDialog alertDialog = alert.create();
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!babyCategory[0].equals("") && !etNutrientsName.getText().toString().equals("") && !etNutrientDose.getText().toString().equals("") && !etNutrientsDesc.getText().toString().equals("")){


                    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                    final String userID=currentUser.getUid();

                    DateFormat df = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
                    DateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
                    String date = df.format(Calendar.getInstance().getTime());
                    String date1 = df1.format(Calendar.getInstance().getTime());


                    database= FirebaseDatabase.getInstance().getReference().child("Nutrients").child(babyCategory[0]).child(date1);

                    HashMap<String,String> userMap=new HashMap<>();
                    userMap.put("name",etNutrientsName.getText().toString());
                    userMap.put("dose",etNutrientDose.getText().toString());
                    userMap.put("desc",etNutrientsDesc.getText().toString());

                    database.setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(getApplicationContext(),"Nutrients Added",Toast.LENGTH_LONG).show();
                            alertDialog.dismiss();
                        }
                    });

                }

            }
        });
        alertDialog.show();

    }

    private void callFirebase(final String selectBaby) {
        database = FirebaseDatabase.getInstance().getReference().child("Nutrients").child(selectBaby);
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                if (!dataSnapshot.exists()) {
                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(), "No Nutrients Yet!", Toast.LENGTH_LONG).show();
                } else {
                    arrayList.clear();
                    progressDialog.dismiss();
                    mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
                    final String uId=mCurrentUser.getUid();

                    for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {



                            String id = childSnapshot.getKey();

                            String name=childSnapshot.child("name").getValue().toString();
                            String dose=childSnapshot.child("dose").getValue().toString();
                            String description=childSnapshot.child("desc").getValue().toString();

                            arrayList.add(new NutrientsDataProvider(id,name,dose,description,selectBaby));




                    }

                    Collections.reverse(arrayList);

                    adapter = new NutrientsActivityAdapter(arrayList, getApplicationContext());
                    int numberOfColumns = 1;
                    LinearLayoutManager MyLayoutManager = new GridLayoutManager(getApplicationContext(), numberOfColumns);
                    recyclerView.setLayoutManager(MyLayoutManager);
                    recyclerView.setAdapter(adapter);


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });
    }
}
