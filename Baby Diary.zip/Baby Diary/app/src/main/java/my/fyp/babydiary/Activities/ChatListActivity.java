package my.fyp.babydiary.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import my.fyp.babydiary.Adapters.ChatListFragmentAdapter;
import my.fyp.babydiary.DataModel.ChatListFragmentDataProvider;
import my.fyp.babydiary.R;

public class ChatListActivity extends AppCompatActivity {


    private String myProfilePrefrence = "profilePrefrence";
    private String keyUSerRole="userRole";
    SharedPreferences sharedPreferences;
    RecyclerView recyclerView;
    DatabaseReference database;
    ArrayList<String> messageSenderIDList;
    ProgressDialog progressDialog;
    ChatListFragmentAdapter adapter;
    ArrayList<ChatListFragmentDataProvider> arrayList;
    String userRole;
    SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);

        recyclerView = (RecyclerView) findViewById(R.id.rvChatList);
        messageSenderIDList = new ArrayList<>();
        arrayList = new ArrayList<ChatListFragmentDataProvider>();
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading....");
        progressDialog.show();

        sharedPreferences = getApplicationContext().getSharedPreferences(myProfilePrefrence, Context.MODE_PRIVATE);
        userRole = sharedPreferences.getString(keyUSerRole, "");
        setTitle("Your Chat");

        callFirebase();


    }

    private void callFirebase() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        final String userID = currentUser.getUid();

        database = FirebaseDatabase.getInstance().getReference().child("Users").child(userID).child("Chat");


        // fetching data from firebase

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //   listView.removeAllViews();
                messageSenderIDList.clear();
                progressDialog.dismiss();

                for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {

                    messageSenderIDList.add(childSnapshot.getKey());

                    //   Toast.makeText(getActivity(),""+childSnapshot.getKey(),Toast.LENGTH_LONG).show();
                }
                fetchSenderDetailsFromID(messageSenderIDList);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progressDialog.dismiss();
                Toast.makeText(ChatListActivity.this, "" + databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void fetchSenderDetailsFromID(final ArrayList<String> messageSenderIDList) {
        database = FirebaseDatabase.getInstance().getReference().child("Users");

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //  listView.removeAllViews();
                arrayList.clear();

                if (!dataSnapshot.exists()) {
                    //    Toast.makeText(getActivity(),"No Such User",Toast.LENGTH_LONG).show();
                } else {
                    for (int i = 0; i < messageSenderIDList.size(); i++) {

                        if (!dataSnapshot.child(messageSenderIDList.get(i)).exists()) {
                            //   Toast.makeText(getActivity(),"No Such User",Toast.LENGTH_LONG).show();
                        } else {
                            String ID = messageSenderIDList.get(i);
                            String Name = dataSnapshot.child(messageSenderIDList.get(i)).child("firstName").getValue().toString();
                            String Phone = dataSnapshot.child(messageSenderIDList.get(i)).child("phone").getValue().toString();
                           String Role = dataSnapshot.child(messageSenderIDList.get(i)).child("userRole").getValue().toString();

                           arrayList.add(new ChatListFragmentDataProvider(ID, Name, Phone, Role));
                        }


                    }
                    adapter = new ChatListFragmentAdapter(arrayList, ChatListActivity.this);
                    int numberOfColumns = 1;
                    LinearLayoutManager MyLayoutManager = new GridLayoutManager(ChatListActivity.this, numberOfColumns);
                    recyclerView.setLayoutManager(MyLayoutManager);
                    recyclerView.setAdapter(adapter);

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}