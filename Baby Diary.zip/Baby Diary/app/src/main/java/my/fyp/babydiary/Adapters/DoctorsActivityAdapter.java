package my.fyp.babydiary.Adapters;

import static android.content.Context.MODE_PRIVATE;
import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

import my.fyp.babydiary.Activities.ChatActivity;
import my.fyp.babydiary.DataModel.DoctorsDataProvider;
import my.fyp.babydiary.R;


public class DoctorsActivityAdapter extends RecyclerView.Adapter<DoctorsActivityAdapter.RecyclerViewHolder>  {
    Context ctx;
    ArrayList<DoctorsDataProvider> arrayList = new ArrayList<DoctorsDataProvider>();
    RecyclerViewHolder recyclerViewHolder;
    FirebaseUser mCurrentUser;
    private String myProfilePrefrence="profilePrefrence";
    private String keyUSerRole="userRole";
    SharedPreferences sharedPreferences;
    String userRole;
    DatabaseReference database;

    public DoctorsActivityAdapter(ArrayList<DoctorsDataProvider> arrayList, Context ctx){

        this.arrayList=arrayList;
        this.ctx=ctx;

    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.doctors_single_item, parent, false);

        recyclerViewHolder = new RecyclerViewHolder(view,ctx);

        sharedPreferences=ctx.getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);
        userRole=sharedPreferences.getString(keyUSerRole,"");

        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.tvName.setText(arrayList.get(position).getName()+" | "+arrayList.get(position).getPhone());

        holder.ivRemoveDoctor.setVisibility(View.GONE);

        if(userRole.equals("admin")){
            holder.tvMessage.setVisibility(View.GONE);
            holder.ivRemoveDoctor.setVisibility(View.VISIBLE);
            holder.tvDesc.setText("\nEmail ID :"+arrayList.get(position).getEmail()+"\n\nPassword : "+arrayList.get(position).getPass()+"\n\nClinic Name: "+arrayList.get(position).getClinicName()+"\n\nClinic Address : "+arrayList.get(position).getClinicAddress()+"\n\nClinic Timing : "+arrayList.get(position).getClinicTiming());

        }else {
            holder.tvMessage.setVisibility(View.VISIBLE);
            holder.tvDesc.setText("Clinic Name: "+arrayList.get(position).getClinicName()+"\n\nClinic Address : "+arrayList.get(position).getClinicAddress()+"\n\nClinic Timing : "+arrayList.get(position).getClinicTiming());

        }

        holder.tvMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//Toast.makeText(ctx,"hello",Toast.LENGTH_LONG).show();
                Intent n=new Intent(ctx, ChatActivity.class);
                n.putExtra("parent","user");
                n.putExtra("id",arrayList.get(position).getId());
                n.putExtra("name",arrayList.get(position).getName());
                n.putExtra("phone",arrayList.get(position).getPhone());
                n.setFlags(FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(n);
            }
        });


        holder.ivRemoveDoctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder alertbox = new AlertDialog.Builder(v.getRootView().getContext());

                alertbox.setTitle("Warning");
                alertbox.setMessage("Do You Want To Remove This Doctor");
                final AlertDialog alertDialog = alertbox.create();
                alertbox.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        removeMedicen(arrayList.get(position).getId());

                        alertDialog.dismiss();
                    }
                });

                alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                alertbox.show();
            }
        });


    }

    private void removeMedicen(String id) {
        database= FirebaseDatabase.getInstance().getReference().child("Doctor").child(id);

        database.removeValue(new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {


                Toast.makeText(ctx,"Medication Removed",Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }



    public static class RecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ImageView ivRemoveDoctor;
        TextView tvName, tvDesc,tvMessage;
        ConstraintLayout constraintLayout;

        Context ctx;

        private RecyclerView recyclerViewHolder;

        @SuppressLint("NewApi")
        public RecyclerViewHolder(View view, Context ctx) {
            super(view);
            view.setOnClickListener(this);
            this.ctx=ctx;
            tvName =(TextView) view.findViewById(R.id.tvDoctorName);
            tvDesc =(TextView) view.findViewById(R.id.tvDoctorDesc);
            constraintLayout =(ConstraintLayout) view.findViewById(R.id.constLayoutHouseDetails);
            ivRemoveDoctor=(ImageView) view.findViewById(R.id.ivRemoveDoctor);
            tvMessage=(TextView) view.findViewById(R.id.tvMessage);
        }

        @Override
        public void onClick(View view) {
            int position=getAdapterPosition();


            switch (position){


            }






        }
    }
}

