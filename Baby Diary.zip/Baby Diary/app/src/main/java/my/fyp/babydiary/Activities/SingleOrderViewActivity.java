package my.fyp.babydiary.Activities;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import my.fyp.babydiary.Adapters.SingleOrderViewAdapter;
import my.fyp.babydiary.DataModel.SingleOrderViewModel;
import my.fyp.babydiary.R;


public class SingleOrderViewActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    SingleOrderViewAdapter adapter;
    ArrayList<SingleOrderViewModel> arrayList;
    ProgressDialog progressDialog;
    private FirebaseUser mCurrentUser;
    DatabaseReference database;
    String dateTime,userRole;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_order_view);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recyclerView=(RecyclerView) findViewById(R.id.rvSingleOrderView);

        arrayList=new ArrayList<SingleOrderViewModel>();
        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Loading..");
        progressDialog.setCancelable(false);
        progressDialog.show();



        dateTime= getIntent().getStringExtra("dateTime");
        userRole=getIntent().getStringExtra("parent");
        setTitle(dateTime);
       // Toast.makeText(getApplicationContext(),""+getIntent().getStringExtra("dateTime"),Toast.LENGTH_LONG).show();
        callFirebase();

    }

    private void callFirebase() {

        mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
        final String uId=mCurrentUser.getUid();

        if(userRole.equals("admin")){
            database = FirebaseDatabase.getInstance().getReference().child("Orders");
            database.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                    if (!dataSnapshot.exists()) {
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(), "No info to get", Toast.LENGTH_LONG).show();
                    } else {
                        arrayList.clear();
                        progressDialog.dismiss();
                        for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {

                            DataSnapshot childSnapshot2=childSnapshot.child(dateTime);


                                for (DataSnapshot childSnapshot3 : childSnapshot2.getChildren()) {

                                    String receiverID,babyCategory,garmentsCategory,customerName,phone,itemPrice,ordernumber,receiverAddress,status,itemName,itemImage,productID,orderStatus,dateTime,productDesc;

                                    productID=childSnapshot3.child("productID").getValue().toString();
                                    orderStatus=childSnapshot3.child("orderStatus").getValue().toString();
                                    dateTime=childSnapshot3.child("dateTime").getValue().toString();
                                    productDesc=childSnapshot3.child("productDesc").getValue().toString();
                                    itemPrice=childSnapshot3.child("productPrice").getValue().toString();
                                    customerName=childSnapshot3.child("receiverName").getValue().toString();
                                    phone=childSnapshot3.child("receiverPhone").getValue().toString();
                                    ordernumber=childSnapshot3.child("orderNumber").getValue().toString();
                                    receiverAddress=childSnapshot3.child("receiverAddress").getValue().toString();
                                    status=childSnapshot3.child("orderStatus").getValue().toString();
                                    itemName=childSnapshot3.child("productName").getValue().toString();
                                    itemImage=childSnapshot3.child("productImage").getValue().toString();
                                    receiverID=childSnapshot3.child("receiverID").getValue().toString();
                                    babyCategory=childSnapshot3.child("babyCategory").getValue().toString();
                                    garmentsCategory=childSnapshot3.child("garmentsCategory").getValue().toString();


                                    arrayList.add(new SingleOrderViewModel(customerName,phone,receiverAddress,receiverID,dateTime,ordernumber,status,itemName,itemPrice,itemImage,productDesc,productID,orderStatus,babyCategory,garmentsCategory));

                                }


                            //  Toast.makeText(getApplicationContext(),""+childSnapshot,Toast.LENGTH_LONG).show();


                        }

                       // Collections.reverse(arrayList);
                        adapter = new SingleOrderViewAdapter(arrayList, SingleOrderViewActivity.this);
                        int numberOfColumns = 1;
                        LinearLayoutManager MyLayoutManager = new GridLayoutManager(getApplicationContext(), numberOfColumns);
                        recyclerView.setLayoutManager(MyLayoutManager);
                        recyclerView.setAdapter(adapter);


                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    progressDialog.dismiss();
                }
            });
        }else if(userRole.equals("user")) {
            database = FirebaseDatabase.getInstance().getReference().child("Orders").child(uId).child(dateTime);
            database.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                    if (!dataSnapshot.exists()) {
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(), "Please Check Your Internet Connection", Toast.LENGTH_LONG).show();
                    } else {
                        arrayList.clear();
                        progressDialog.dismiss();
                        for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {

                            //  Toast.makeText(getApplicationContext(),""+childSnapshot,Toast.LENGTH_LONG).show();

                            String receiverID,babyCategory,garmentsCategory,customerName,phone,ordernumber,receiverAddress,status,itemName,itemPrice,itemImage,productID,orderStatus,dateTime,productDesc;

                            productID=childSnapshot.child("productID").getValue().toString();
                            orderStatus=childSnapshot.child("orderStatus").getValue().toString();
                            dateTime=childSnapshot.child("dateTime").getValue().toString();
                            productDesc=childSnapshot.child("productDesc").getValue().toString();
                            customerName=childSnapshot.child("receiverName").getValue().toString();
                            phone=childSnapshot.child("receiverPhone").getValue().toString();
                            ordernumber=childSnapshot.child("orderNumber").getValue().toString();
                            status=childSnapshot.child("orderStatus").getValue().toString();
                            itemName=childSnapshot.child("productName").getValue().toString();
                            itemPrice=childSnapshot.child("productPrice").getValue().toString();
                            itemImage=childSnapshot.child("productImage").getValue().toString();
                            receiverID=childSnapshot.child("receiverID").getValue().toString();
                            receiverAddress=childSnapshot.child("receiverAddress").getValue().toString();
                            babyCategory=childSnapshot.child("babyCategory").getValue().toString();
                            garmentsCategory=childSnapshot.child("garmentsCategory").getValue().toString();



                            arrayList.add(new SingleOrderViewModel(customerName,phone,receiverAddress,receiverID,dateTime,ordernumber,status,itemName,itemPrice,itemImage,productDesc,productID,orderStatus,babyCategory,garmentsCategory));

                        }

                       // Collections.reverse(arrayList);
                        adapter = new SingleOrderViewAdapter(arrayList, SingleOrderViewActivity.this);
                        int numberOfColumns = 1;
                        LinearLayoutManager MyLayoutManager = new GridLayoutManager(getApplicationContext(), numberOfColumns);
                        recyclerView.setLayoutManager(MyLayoutManager);
                        recyclerView.setAdapter(adapter);


                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    progressDialog.dismiss();
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }

        return super.onOptionsItemSelected(menuItem);
    }

}