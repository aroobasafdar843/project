package my.fyp.babydiary.DataModel;

public class GarmentsDataProvider {


    String advertTime;
    String productImage;
    String babyCategory;
    String garmentsCategory;
    String productName;
    String productPrice;
    String productDescription;
    String receiverID;
    String receiverName;

    public GarmentsDataProvider(String advertTime, String productImage, String babyCategory, String garmentsCategory, String productName, String productPrice, String productDescription, String receiverID, String receiverName) {
        this.advertTime = advertTime;
        this.productImage = productImage;
        this.babyCategory = babyCategory;
        this.garmentsCategory = garmentsCategory;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productDescription = productDescription;
        this.receiverID = receiverID;
        this.receiverName = receiverName;
    }

    public String getAdvertTime() {
        return advertTime;
    }

    public void setAdvertTime(String advertTime) {
        this.advertTime = advertTime;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getBabyCategory() {
        return babyCategory;
    }

    public void setBabyCategory(String babyCategory) {
        this.babyCategory = babyCategory;
    }

    public String getGarmentsCategory() {
        return garmentsCategory;
    }

    public void setGarmentsCategory(String garmentsCategory) {
        this.garmentsCategory = garmentsCategory;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getReceiverID() {
        return receiverID;
    }

    public void setReceiverID(String receiverID) {
        this.receiverID = receiverID;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }
}
