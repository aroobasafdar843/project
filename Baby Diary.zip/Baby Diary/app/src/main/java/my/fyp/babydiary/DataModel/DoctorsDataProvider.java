package my.fyp.babydiary.DataModel;

public class DoctorsDataProvider {

    String id;
    String email;
    String pass;
    String name;
    String phone;
    String clinicName;
    String clinicAddress;
    String clinicTiming;

    public DoctorsDataProvider(String id, String email, String pass, String name, String phone, String clinicName, String clinicAddress, String clinicTiming) {
        this.id = id;
        this.email = email;
        this.pass = pass;
        this.name = name;
        this.phone = phone;
        this.clinicName = clinicName;
        this.clinicAddress = clinicAddress;
        this.clinicTiming = clinicTiming;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public String getClinicAddress() {
        return clinicAddress;
    }

    public void setClinicAddress(String clinicAddress) {
        this.clinicAddress = clinicAddress;
    }

    public String getClinicTiming() {
        return clinicTiming;
    }

    public void setClinicTiming(String clinicTiming) {
        this.clinicTiming = clinicTiming;
    }
}

