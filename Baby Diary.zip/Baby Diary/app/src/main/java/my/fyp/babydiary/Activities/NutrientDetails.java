package my.fyp.babydiary.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import my.fyp.babydiary.R;

public class NutrientDetails extends AppCompatActivity {

    TextView tvDetails;
    String name,dose,desc;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrient_details);

        tvDetails=(TextView) findViewById(R.id.textViewDetails);

        name=getIntent().getStringExtra("name");
        dose=getIntent().getStringExtra("dose");
        desc=getIntent().getStringExtra("desc");
        tvDetails.setText("Name: "+name+"\n\nDose: "+dose+"\n\nDescription: "+desc);
    }
}