package my.fyp.babydiary.DataModel;

import java.io.Serializable;


public class ShoppingItem implements Serializable{

    private String productID,name,price, description,productImage,receiverName,receiverPhone,babyCategory,garmentsCategory;

    public ShoppingItem(String productID, String name, String price, String description, String productImage, String receiverName, String receiverPhone, String babyCategory, String garmentsCategory) {
        this.productID = productID;
        this.name = name;
        this.price = price;
        this.description = description;
        this.productImage = productImage;
        this.receiverName = receiverName;
        this.receiverPhone = receiverPhone;
        this.babyCategory = babyCategory;
        this.garmentsCategory = garmentsCategory;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getReceiverPhone() {
        return receiverPhone;
    }

    public void setReceiverPhone(String receiverPhone) {
        this.receiverPhone = receiverPhone;
    }

    public String getBabyCategory() {
        return babyCategory;
    }

    public void setBabyCategory(String babyCategory) {
        this.babyCategory = babyCategory;
    }

    public String getGarmentsCategory() {
        return garmentsCategory;
    }

    public void setGarmentsCategory(String garmentsCategory) {
        this.garmentsCategory = garmentsCategory;
    }
}
