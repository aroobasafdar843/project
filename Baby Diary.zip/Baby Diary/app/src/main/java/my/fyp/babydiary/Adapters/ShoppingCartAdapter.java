package my.fyp.babydiary.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.squareup.picasso.Picasso;



import java.util.ArrayList;
import java.util.List;

import my.fyp.babydiary.DataModel.ShoppingItem;
import my.fyp.babydiary.R;


public class ShoppingCartAdapter extends ArrayAdapter {
    Context context;
    ArrayList<ShoppingItem> items;
    DatabaseReference database;
    ArrayList<String> productImagesList=new ArrayList<>();
    DatabaseReference myRef;
    public ShoppingCartAdapter(Context context, List<ShoppingItem> items){
        super(context, 0, items);
        this.context = context;
        this.items = (ArrayList<ShoppingItem>) items;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.cart_item, parent, false
            );
        }

        final ShoppingItem currentItem = (ShoppingItem) getItem(position);


        final ViewFlipper viewFlipper=(ViewFlipper)  listItemView.findViewById(R.id.cartItemIcon);

        database= FirebaseDatabase.getInstance().getReference().child("Product Images").child(currentItem.getProductImage());

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                productImagesList.clear();
                for (DataSnapshot childSnapshot1 : snapshot.getChildren()) {

                    String url=childSnapshot1.getValue().toString();
                    productImagesList.add(url);
                    //      Toast.makeText(ctx,"url"+url,Toast.LENGTH_LONG).show();
                }
                for (int i=0;i<productImagesList.size();i++){
                    ImageView imageView=new ImageView(context);

                    Picasso.with(context).load(productImagesList.get(i)).placeholder(R.drawable.iconaddproduct100).into(imageView);
                    // imageView.setScaleType(ImageView.ScaleType.FIT_XY);
                    viewFlipper.addView(imageView);
                    viewFlipper.setFlipInterval(3000);
                    viewFlipper.setAutoStart(true);
                    viewFlipper.setInAnimation(context,android.R.anim.slide_in_left);
                    viewFlipper.setOutAnimation(context,android.R.anim.slide_out_right);
                    viewFlipper.startFlipping();


                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });


        TextView tvItemName= (TextView) listItemView.findViewById(R.id.cartItemName);
        tvItemName.setText("Baby Category : "+currentItem.getBabyCategory()+"\nGarments Category : "+currentItem.getGarmentsCategory()+"\nProduct Name: "+currentItem.getName()+"\nProduct Price: "+currentItem.getPrice()+" Rs.");



        return listItemView;
    }

    private void RemoveFromCart() {

    }
}
