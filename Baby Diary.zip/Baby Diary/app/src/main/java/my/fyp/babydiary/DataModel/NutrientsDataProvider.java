package my.fyp.babydiary.DataModel;

public class NutrientsDataProvider {

    String id;
    String name;
    String dose;
    String description;
    String babyCategory;

    public NutrientsDataProvider(String id, String name, String dose, String description, String babyCategory) {
        this.id = id;
        this.name = name;
        this.dose = dose;
        this.description = description;
        this.babyCategory = babyCategory;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDose() {
        return dose;
    }

    public void setDose(String dose) {
        this.dose = dose;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBabyCategory() {
        return babyCategory;
    }

    public void setBabyCategory(String babyCategory) {
        this.babyCategory = babyCategory;
    }
}

