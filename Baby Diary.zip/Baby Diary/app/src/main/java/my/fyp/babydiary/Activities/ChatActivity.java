package my.fyp.babydiary.Activities;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import my.fyp.babydiary.DataModel.ChatDataProvider;
import my.fyp.babydiary.R;


public class ChatActivity extends AppCompatActivity {

    LinearLayout layout;
    RelativeLayout layout_2;
    ImageView sendButton;
    EditText messageArea;
    ScrollView scrollView;
    ProgressDialog progressDialog;
    private DatabaseReference mDatabase,mDatabase2;

    String chatWithName;
    ArrayList<ChatDataProvider> arrayList;
    String receiverId, senderID;

    private SharedPreferences sharedPreferences;
    private String myProfilePrefrence="profilePrefrence";
    private String keyIsLoggedIn="isLoggedIn";
    private String keyUserName="name";
    private String keyUserEmail="email";
    private String keyUserPassword="password";
    private String keyUserPhone="phone";
    private String keyUserImage="image";
    private String keyUserGander="gander";
    private String keyUserAddress="address";
    private String keyUSerRole="userRole";
    private String keyTeachingSubject="teachingSubject";
    private String keyTeachingExperience="teachingExperience";

    String userRole;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        sharedPreferences=getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);
        userRole=sharedPreferences.getString(keyUSerRole,"");
        arrayList=new ArrayList<>();
        layout = (LinearLayout) findViewById(R.id.layout1);
        layout_2 = (RelativeLayout)findViewById(R.id.layout2);
        sendButton = (ImageView)findViewById(R.id.sendButton);
        messageArea = (EditText)findViewById(R.id.messageArea);
        scrollView = (ScrollView)findViewById(R.id.scrollView);

        scrollView.fullScroll(View.FOCUS_DOWN);

        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();


        chatWithName=(getIntent().getStringExtra("name")+"("+getIntent().getStringExtra("phone")+")");
        receiverId=(getIntent().getStringExtra("id"));

        final FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        senderID =currentUser.getUid();
        setTitle(chatWithName);



        // receiverID=getIntent().getStringExtra("tutorID");



        mDatabase= FirebaseDatabase.getInstance().getReference().child("Users").child(senderID).child("Chat").child(receiverId);

        mDatabase2= FirebaseDatabase.getInstance().getReference().child("Users").child(receiverId).child("Chat").child(senderID);


        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String messageText = messageArea.getText().toString();

                DateFormat df = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
                DateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
                String date = df.format(Calendar.getInstance().getTime());
                String date1 = df1.format(Calendar.getInstance().getTime());

                if(!messageText.equals("")){

                    Map<String, Object> map = new HashMap<String, Object>();
                    map.put("message", messageText);
                    map.put("senderName", sharedPreferences.getString(keyUserName,"name"));
                    map.put("senderID", senderID);
                    map.put("messageTime", date);
                    mDatabase.push().updateChildren(map);
                    mDatabase2.push().updateChildren(map);
                    messageArea.setText("");

                }
            }
        });

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                arrayList.clear();
                int i=0;
                layout.removeAllViews();
                progressDialog.dismiss();
                if(!dataSnapshot.exists()){
                    Toast.makeText(getApplicationContext(),"No Chat Yet!",Toast.LENGTH_LONG).show();
                }else {
                    for (DataSnapshot dataSnapshot1: dataSnapshot.getChildren()) {


                        arrayList.add(new ChatDataProvider(dataSnapshot1.child("message").getValue().toString(), dataSnapshot1.child("senderName").getValue().toString(),dataSnapshot1.child("senderID").getValue().toString(),dataSnapshot1.child("messageTime").getValue().toString()));


                        if (arrayList.get(i).getSenderID().equals(senderID)) {
                            addMessageBox("-:You"+"\n" + arrayList.get(i).getMessage()+"\n\n("+arrayList.get(i).getMessageTime()+")", 1);
                        } else {
                            addMessageBox(arrayList.get(i).getSenderName()+":-\n" + arrayList.get(i).getMessage()+"\n\n("+arrayList.get(i).getMessageTime()+")", 2);
                        }

                        
                        i++;


                    }
                }

            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    public void addMessageBox(String message, int type){
        final TextView textView = new TextView(ChatActivity.this);
        textView.setText(message);



        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp2.weight = 1.0f;

        if(type == 1) {
            lp2.gravity = Gravity.RIGHT;
            textView.setGravity(Gravity.RIGHT);
            textView.setBackgroundResource(R.drawable.bubble_in);
        }
        else{
            lp2.gravity = Gravity.LEFT;
            textView.setGravity(Gravity.LEFT);
            textView.setBackgroundResource(R.drawable.bubble_out);
        }
        textView.setLayoutParams(lp2);
        layout.addView(textView);
        scrollView.fullScroll(View.FOCUS_DOWN);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                onBackPressed();

                break;
        }

        return super.onOptionsItemSelected(menuItem);
    }
}