package my.fyp.babydiary.Fragments;

import static android.content.Context.MODE_PRIVATE;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;

import my.fyp.babydiary.Activities.SingleOrderViewActivity;
import my.fyp.babydiary.R;


public class ProcessingOrders extends Fragment {

    ListView listView;
    DatabaseReference database;
    ArrayList<String> orderDate;
    ProgressDialog progressDialog;
    SharedPreferences sharedPreferences;
    private String keyUSerRole="userRole";
    private String keyUserName="name";
    private String myProfilePrefrence="profilePrefrence";
    String userRole;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_processing_orders, container, false);


        sharedPreferences=getActivity().getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);
        userRole=sharedPreferences.getString(keyUSerRole, null);

        listView=(ListView) view.findViewById(R.id.lvProcessingOrders);
        orderDate =new ArrayList<>();
        progressDialog=new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading....");
        progressDialog.show();

        callFirebase();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String dateTime= (String) adapterView.getItemAtPosition(i);

                Intent n=new Intent(getActivity(), SingleOrderViewActivity.class);
                n.putExtra("dateTime",dateTime);
                n.putExtra("parent",userRole);
                startActivity(n);

            }
        });



        return view;
    }

    private void callFirebase() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        final String userID=currentUser.getUid();
        if(userRole.equals("admin")){
            database= FirebaseDatabase.getInstance().getReference().child("Orders");
            database.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    orderDate.clear();
                    progressDialog.dismiss();
                    for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {

                        for (DataSnapshot childSnapshot2 : childSnapshot.getChildren()) {

                             String date=childSnapshot2.child("item1").child("dateTime").getValue().toString();
                            String status=childSnapshot2.child("item1").child("orderStatus").getValue().toString();
                       //     Toast.makeText(getActivity(),""+date,Toast.LENGTH_LONG).show();
                            if(status.equals("Requested") || status.equals("Accepted") ){
                                orderDate.add(date);
                            }

                        }

                    }
                    Collections.reverse(orderDate);
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, android.R.id.text1, orderDate);
                    listView.setAdapter(adapter);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(),""+databaseError.getMessage(),Toast.LENGTH_LONG).show();
                }
            });
        }else if(userRole.equals("user")){
            database= FirebaseDatabase.getInstance().getReference().child("Orders").child(userID);
            database.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    orderDate.clear();
                    progressDialog.dismiss();
                    for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {



                            String date=childSnapshot.child("item1").child("dateTime").getValue().toString();
                            String status=childSnapshot.child("item1").child("orderStatus").getValue().toString();

                        if(status.equals("Requested") || status.equals("Accepted") ){
                            orderDate.add(date);
                        }


                    }
                    Collections.reverse(orderDate);
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, android.R.id.text1, orderDate);
                    listView.setAdapter(adapter);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(),""+databaseError.getMessage(),Toast.LENGTH_LONG).show();
                }
            });
        }

    }
}