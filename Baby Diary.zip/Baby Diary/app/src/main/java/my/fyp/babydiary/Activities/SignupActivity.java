package my.fyp.babydiary.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import my.fyp.babydiary.R;

public class SignupActivity extends AppCompatActivity {

    EditText etFirstName,etLastName,etEmail,etPassword,etConfirmPass,etphone;
    Button btnSignup;
    TextView tvHaveAccount;


    private FirebaseAuth mAuth;
    ProgressDialog progressDialog;
    DatabaseReference database;
    SharedPreferences sharedPreferences;
    private String myProfilePrefrence="profilePrefrence";
    private String keyIsLoggedIn="isLoggedIn";
    private String keyFirstName="fName";
    private String keyLastName="lName";
    private String keyEmail="email";
    private String keyPassword="password";
    private String keyUSerRole="userRole";
    private String keyPhone="phone";
    private Boolean isLoggedIn;
    String fname, lname, email, password, phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);


        mAuth = FirebaseAuth.getInstance();
        etFirstName=(EditText) findViewById(R.id.etSignupFirstName);
        etLastName=(EditText) findViewById(R.id.etSignupLastName);
        etEmail=(EditText) findViewById(R.id.etSignupEmail);
        etPassword=(EditText) findViewById(R.id.etSignupPass);
        etConfirmPass=(EditText) findViewById(R.id.etSignupConfirmPass);
        etphone=(EditText) findViewById(R.id.etSignupPhone);
        btnSignup=(Button) findViewById(R.id.btnSignup);
        tvHaveAccount=(TextView) findViewById(R.id.tvHaveAccount);

        progressDialog=new ProgressDialog(this);

        sharedPreferences=getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);
        isLoggedIn=sharedPreferences.getBoolean("isLoggedIn",false);

        // Receiving data if already existing
        if(isLoggedIn==true){
            String fname,lname,pass,email,phone;
            fname=sharedPreferences.getString(keyFirstName,"First Name");
            lname=sharedPreferences.getString(keyLastName,"Last Name");
            pass=sharedPreferences.getString(keyPassword,"Password");
            email=sharedPreferences.getString(keyEmail,"Email");
            phone=sharedPreferences.getString(keyPhone,"Phone");

            getSupportActionBar().setTitle("Your Profile");
            btnSignup.setVisibility(View.GONE);
            tvHaveAccount.setVisibility(View.INVISIBLE);
            etFirstName.setText(fname);
            etLastName.setText(lname);
            etPassword.setText(pass);
            etConfirmPass.setText(pass);
            etEmail.setText(email);
            etphone.setText(phone);
        }


        /*etEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!etEmail.getText().toString().equals("")){
                    String emailRegex ="^[_A-Za-z0-9-]+(\\\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\\\.[A-Za-z0-9]+)*(\\\\.[A-Za-z]{2,})$";
                    if(!etEmail.getText().toString().matches(emailRegex)){
                        etEmail.setError("Email formate Is invalid");
                        fname="";
                    }else {
                        fname=etEmail.getText().toString();
                    }

                }
            }
        });*/




        etPassword.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!etPassword.getText().toString().equals("")){
                    if(etPassword.getText().toString().length()<6){
                        etPassword.setError("password minimum length is 6");
                    }
                    else {
                        password=etPassword.getText().toString();
                    }
                }
            }
        });


        etConfirmPass.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!etPassword.getText().toString().equals("") && !etConfirmPass.getText().toString().equals("")){
                    if(!etPassword.getText().toString().equals(etConfirmPass.getText().toString())){
                      etConfirmPass.setError("Password Does Not match");
                        Toast.makeText(SignupActivity.this,"Password Does Not match", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });


        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // check if all the fields are filled up
                if (etFirstName.getText().toString().equals("") || etLastName.getText().toString().equals("") || etEmail.getText().toString().equals("") || etConfirmPass.getText().toString().equals("") || etphone.getText().toString().equals("")) {
                    Toast.makeText(SignupActivity.this, "Please input all filelds", Toast.LENGTH_LONG).show();
                }
                else {
                    String emailRegex ="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
                    if(!etEmail.getText().toString().matches(emailRegex)){

                        Toast.makeText(SignupActivity.this,"Invalid Email", Toast.LENGTH_LONG).show();
                    }
                    else if(etPassword.getText().toString().length()<6){
                        Toast.makeText(SignupActivity.this,"password minimum length is 6", Toast.LENGTH_LONG).show();
                    }
                    else {
                        fname = etFirstName.getText().toString();
                        lname = etLastName.getText().toString();
                        email = etEmail.getText().toString();
                        password = etPassword.getText().toString();
                        phone = etphone.getText().toString();
                        progressDialog.setTitle("Creating Account");
                        progressDialog.setMessage("Please Wait");
                        progressDialog.setCancelable(false);
                        progressDialog.show();
                        register_user(fname,lname,email,password,phone);
                    }



                    }


            }
        });
    }

    private void register_user(final String fname, final String lname, final String email, final String password, final String phone) {

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            progressDialog.dismiss();
                            // Sign in success, update UI with the signed-in user's information

                            /*for sending verification email*/
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                            if(user != null){
                                user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful()){
                                            Toast.makeText(SignupActivity.this,"check email for verification",Toast.LENGTH_LONG).show();

                                        }
                                    }
                                });
                            }

                            String uId=user.getUid();

                            database=FirebaseDatabase.getInstance().getReference().child("Users").child(uId);

                            HashMap<String, String> userMap=new HashMap<>();
                            userMap.put("firstName",fname);
                            userMap.put("lastName",lname);
                            userMap.put("email",email);
                            userMap.put("password",password);
                            userMap.put("phone",phone);
                            userMap.put("userRole","user");
                            database.setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){


                                       /* SharedPreferences.Editor editor=sharedPreferences.edit();
                                        editor.putBoolean(keyIsLoggedIn,true);
                                        editor.putString(keyFirstName,fname);
                                        editor.putString(keyLastName,lname);
                                        editor.putString(keyEmail,email);
                                        editor.putString(keyPassword,password);
                                        editor.putString(keyPhone,phone);
                                        editor.putString(keyUSerRole,"user");
                                        editor.commit();*/

                                        progressDialog.dismiss();
                                        Toast.makeText(getApplicationContext(),"Check Your Email Account for Verification",Toast.LENGTH_SHORT).show();
                                        finish();

                                       // finish();
                                    }
                                }
                            });


                            Toast.makeText(SignupActivity.this,"Signup Successful", Toast.LENGTH_SHORT).show();


                        } else {
                            progressDialog.dismiss();
                            Toast.makeText(SignupActivity.this,""+task.getException(), Toast.LENGTH_SHORT).show();

                        }


                    }
                });
    }
}
