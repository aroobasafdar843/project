package my.fyp.babydiary.Activities;


import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthCredential;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import my.fyp.babydiary.Activities.ChatListActivity;
import my.fyp.babydiary.Activities.DoctorsActivity;
import my.fyp.babydiary.Activities.GarmentsActivity;
import my.fyp.babydiary.Activities.LoginActivity;
import my.fyp.babydiary.Activities.NutrientsActivity;
import my.fyp.babydiary.Activities.OrderHistory;
import my.fyp.babydiary.Activities.Reminder;
import my.fyp.babydiary.Activities.SignupActivity;
import my.fyp.babydiary.R;

import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity  implements NavigationView.OnNavigationItemSelectedListener{

    SharedPreferences sharedPreferences;
    private String myProfilePrefrence="profilePrefrence";
    private String keyIsLoggedIn="isLoggedIn";
    private Boolean isLoggedIn;
    private String userName;
    NavigationView navigationView;
    private String keyFirstName="fName";
    private String keyUSerRole="userRole";
    TextView tvUserNAme;
    Menu nav_Menu;
    Button btnReminder, btnNutrients, btnGarments,btnDoctors,btnChat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        sharedPreferences=getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);
        isLoggedIn=sharedPreferences.getBoolean(keyIsLoggedIn,false);
        userName=sharedPreferences.getString("fName","name");

        btnReminder =(Button) findViewById(R.id.btnBabyActivitesReminder);

        btnNutrients =(Button) findViewById(R.id.btnNutrients);
        btnDoctors =(Button) findViewById(R.id.btnDoctors);
        btnGarments=(Button) findViewById(R.id.btnGarments);
        btnChat=(Button) findViewById(R.id.btnChat);

        btnChat.setVisibility(View.GONE);


        btnReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Reminder.class));
            }
        });

        btnNutrients.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), NutrientsActivity.class));
            }
        });

        btnDoctors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), DoctorsActivity.class));
            }
        });

        btnGarments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), GarmentsActivity.class));
            }
        });

        btnChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ChatListActivity.class));
            }
        });

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        View headerview = navigationView.getHeaderView(0);
        nav_Menu = navigationView.getMenu();
        nav_Menu.findItem(R.id.nav_chat).setVisible(false);

        nav_Menu.findItem(R.id.nav_order_history).setVisible(true);

        if(sharedPreferences.getString(keyUSerRole,"").equals("Doctor")){
            btnDoctors.setVisibility(View.GONE);
            btnGarments.setVisibility(View.GONE);
            btnNutrients.setVisibility(View.GONE);
            btnReminder.setVisibility(View.GONE);
            btnChat.setVisibility(View.VISIBLE);

            nav_Menu.findItem(R.id.nav_doctors).setVisible(false);
            nav_Menu.findItem(R.id.nav_garments).setVisible(false);
            nav_Menu.findItem(R.id.nav_Nutrients).setVisible(false);
            nav_Menu.findItem(R.id.nav_baby_activites_Reminder).setVisible(false);
            nav_Menu.findItem(R.id.nav_order_history).setVisible(false);
            nav_Menu.findItem(R.id.nav_chat).setVisible(true);

        }
        // header click listenser to edit profile

        tvUserNAme=headerview.findViewById(R.id.tvUserName);


        if (sharedPreferences.contains(keyFirstName)) {
            tvUserNAme.setText(sharedPreferences.getString(keyFirstName, "User Name")+"\nView Your Profile");

        }


        headerview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent n=new Intent(MainActivity.this, SignupActivity.class);
                startActivity(n);
            }
        });

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            Intent n=new Intent();
            n.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this,R.style.AlertDialogTheme);
            builder.setIcon(R.drawable.applogo);
            builder.setTitle("Alert");
            builder.setMessage("click ok to exit");
            builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.show();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.


        switch (item.getItemId()){

            // click listener on navigation drawer items
            case R.id.nav_baby_activites_Reminder:
                Intent n;
                startActivity(new Intent(getApplicationContext(),Reminder.class));
                break;


            case R.id.nav_Nutrients:
                n=new Intent(MainActivity.this, NutrientsActivity.class);
                startActivity(n);
                break;
            case R.id.nav_garments:

                n=new Intent(MainActivity.this, GarmentsActivity.class);
                startActivity(n);
                break;

            case R.id.nav_doctors:

                n=new Intent(MainActivity.this, DoctorsActivity.class);
                startActivity(n);

                break;

            case R.id.nav_order_history:

                n=new Intent(MainActivity.this, OrderHistory.class);
                startActivity(n);

                break;

            case R.id.nav_logout:

                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putBoolean("isLoggedIn",false);
                editor.commit();
                FirebaseAuth.getInstance().signOut();

                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();

                Toast.makeText(getApplicationContext(),"Logged Out",Toast.LENGTH_SHORT).show();

                break;

            case R.id.nav_share:
                try {
                    PackageManager pm = getPackageManager();
                    ApplicationInfo ai = pm.getApplicationInfo(getPackageName(), 0);
                    File srcFile = new File(ai.publicSourceDir);
                    Intent share = new Intent();
                    share.setAction(Intent.ACTION_SEND);
                    share.setType("application/vnd.android.package-archive");
                    share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(srcFile));
                    startActivity(Intent.createChooser(share, getString(R.string.app_name)));
                } catch (Exception e) {
                    Log.e("ShareApp", e.getMessage());
                }
                break;
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;

    }
}
