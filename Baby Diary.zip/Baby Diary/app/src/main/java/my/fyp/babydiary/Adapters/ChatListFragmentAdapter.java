package my.fyp.babydiary.Adapters;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

import my.fyp.babydiary.Activities.ChatActivity;
import my.fyp.babydiary.DataModel.ChatListFragmentDataProvider;
import my.fyp.babydiary.R;


public class ChatListFragmentAdapter extends RecyclerView.Adapter<ChatListFragmentAdapter.RecyclerViewHolder>  {
    Context ctx;
    ArrayList<ChatListFragmentDataProvider> arrayList = new ArrayList<ChatListFragmentDataProvider>();
    RecyclerViewHolder recyclerViewHolder;
    private String myProfilePrefrence="profilePrefrence";
    private String keyUserRole="role";
    SharedPreferences sharedPreferences;
    String userRole;

    public ChatListFragmentAdapter(ArrayList<ChatListFragmentDataProvider> arrayList, Context ctx){

        this.arrayList=arrayList;
        this.ctx=ctx;

    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_single_item, parent, false);

        recyclerViewHolder = new RecyclerViewHolder(view,ctx);

        sharedPreferences=ctx.getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);
        userRole=sharedPreferences.getString(keyUserRole,"");

        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        //holder.tvTeachingSubject.setText(arrayList.get(position).getSubject());

        holder.ivRemoveChat.setVisibility(View.VISIBLE);

        String name=arrayList.get(position).getName();
        String phone=arrayList.get(position).getPhone();

        holder.tvName.setText(name+" | "+phone);

        holder.constLayoutSingleUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent n=new Intent(ctx, ChatActivity.class);
                n.putExtra("id",arrayList.get(position).getId());
                n.putExtra("name",arrayList.get(position).getName());
                n.putExtra("phone",arrayList.get(position).getPhone());
                n.putExtra("parent",userRole);

                ctx.startActivity(n);

                //   Toast.makeText(ctx,"Role"+arrayList.get(position).getRole(),Toast.LENGTH_LONG).show();
            }
        });


        holder.ivRemoveChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseUser mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
                final String uId=mCurrentUser.getUid();

                final AlertDialog.Builder alertbox = new AlertDialog.Builder(view.getRootView().getContext());

                alertbox.setTitle("Warning");
                alertbox.setMessage("Do You Want To Delete This Chat");
                final AlertDialog alertDialog = alertbox.create();
                alertbox.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        deleteChat(arrayList.get(position).getId(),uId);
                        //   Toast.makeText(ctx,arrayList.get(position).getPostID(),Toast.LENGTH_LONG).show();

                        alertDialog.dismiss();
                    }
                });

                alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                alertbox.show();

            }
        });


    }

    private void deleteChat(String othersID, String CurrentUserID) {
        String studentID = null,focalPersonID=null;
        if(userRole.equals("user") || userRole.equals("admin")){
            studentID=CurrentUserID;
            focalPersonID=othersID;
        }else {
            studentID=othersID;
            focalPersonID=CurrentUserID;
        }

        DatabaseReference mDatabase= FirebaseDatabase.getInstance().getReference().child(focalPersonID).child("Chat").child(studentID);

        mDatabase.removeValue(new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {


              //  Toast.makeText(ctx,"Chat Deleted",Toast.LENGTH_LONG).show();
            }
        });

        DatabaseReference mDatabase1= FirebaseDatabase.getInstance().getReference().child(studentID).child("Chat").child(focalPersonID);

        mDatabase1.removeValue(new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {


                Toast.makeText(ctx,"Chat Deleted",Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }



    public static class RecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView tvName;

        Context ctx;
        ConstraintLayout constLayoutSingleUser;
        ImageView ivRemoveChat;
        @SuppressLint("NewApi")
        public RecyclerViewHolder(View view, Context ctx) {
            super(view);
            view.setOnClickListener(this);
            this.ctx=ctx;

            tvName =(TextView) view.findViewById(R.id.tvName);
            ivRemoveChat=(ImageView) view.findViewById(R.id.ivRemoveChat);
            constLayoutSingleUser=(ConstraintLayout) view.findViewById(R.id.constLayoutSingleUser);

        }

        @Override
        public void onClick(View view) {
            int position=getAdapterPosition();







        }
    }
}

