package my.fyp.babydiary.Adapters;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import my.fyp.babydiary.Activities.NutrientDetails;
import my.fyp.babydiary.DataModel.NutrientsDataProvider;
import my.fyp.babydiary.R;

import static android.content.Context.MODE_PRIVATE;


public class NutrientsActivityAdapter extends RecyclerView.Adapter<NutrientsActivityAdapter.RecyclerViewHolder>  {
    Context ctx;
    ArrayList<NutrientsDataProvider> arrayList = new ArrayList<NutrientsDataProvider>();
    RecyclerViewHolder recyclerViewHolder;
    FirebaseUser mCurrentUser;
    private String myProfilePrefrence="profilePrefrence";
    private String keyUserRole="userRole";
    SharedPreferences sharedPreferences;
    String userRole;
    DatabaseReference database;

    public NutrientsActivityAdapter(ArrayList<NutrientsDataProvider> arrayList, Context ctx){

        this.arrayList=arrayList;
        this.ctx=ctx;

    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.nutrients_single_item, parent, false);

        recyclerViewHolder = new RecyclerViewHolder(view,ctx);

        sharedPreferences=ctx.getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);
        userRole=sharedPreferences.getString(keyUserRole,"");

        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.ivRemoveMedicen.setVisibility(View.GONE);

        if(userRole.equals("admin")){
            holder.ivRemoveMedicen.setVisibility(View.VISIBLE);

        }

        holder.constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent n=new Intent(ctx, NutrientDetails.class);
                n.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                n.putExtra("name",arrayList.get(position).getName());
                n.putExtra("dose",arrayList.get(position).getDose());
                n.putExtra("desc",arrayList.get(position).getDescription());
                ctx.startActivity(n);
            }
        });

        holder.tvMedicenName.setText(arrayList.get(position).getName()+"\nDose : "+arrayList.get(position).getDose());
        holder.tvMedicenDesc.setText(arrayList.get(position).getDescription());



        holder.ivRemoveMedicen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder alertbox = new AlertDialog.Builder(v.getRootView().getContext());

                alertbox.setTitle("Warning");
                alertbox.setMessage("Do You Want To Remove This User");
                final android.app.AlertDialog alertDialog = alertbox.create();
                alertbox.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        removeNutrient(arrayList.get(position).getId(),arrayList.get(position).getBabyCategory());

                        alertDialog.dismiss();
                    }
                });

                alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                alertbox.show();
            }
        });


    }

    private void removeNutrient(String id,String babyCategory) {
        database= FirebaseDatabase.getInstance().getReference().child("Nutrients").child(babyCategory).child(id);

        database.removeValue(new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {


                Toast.makeText(ctx,"Nutrient Removed",Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }



    public static class RecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ImageView ivMedicenImage,ivRemoveMedicen;
        TextView tvMedicenName, tvMedicenDesc;
        ConstraintLayout constraintLayout;

        Context ctx;

        private RecyclerView recyclerViewHolder;

        @SuppressLint("NewApi")
        public RecyclerViewHolder(View view, Context ctx) {
            super(view);
            view.setOnClickListener(this);
            this.ctx=ctx;
            ivMedicenImage =(ImageView) view.findViewById(R.id.ivMEdicenImage);
            tvMedicenName =(TextView) view.findViewById(R.id.tvMedicenName);
            tvMedicenDesc =(TextView) view.findViewById(R.id.tvMedicenDesc);
            constraintLayout =(ConstraintLayout) view.findViewById(R.id.constLayoutNutrientDetails);
            ivRemoveMedicen=(ImageView) view.findViewById(R.id.ivRemoveMedicen);
        }

        @Override
        public void onClick(View view) {
            int position=getAdapterPosition();


            switch (position){


            }






        }
    }
}

