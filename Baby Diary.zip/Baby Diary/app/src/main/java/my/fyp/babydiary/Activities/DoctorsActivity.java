package my.fyp.babydiary.Activities;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

import my.fyp.babydiary.Adapters.DoctorsActivityAdapter;
import my.fyp.babydiary.DataModel.DoctorsDataProvider;
import my.fyp.babydiary.R;

public class DoctorsActivity extends AppCompatActivity {


    RecyclerView rvDoctors;
    DoctorsActivityAdapter adapter;
    ArrayList<DoctorsDataProvider> arrayList;
    DatabaseReference database;
    ProgressDialog progressDialog;
    FloatingActionButton fabAddDoctors;

    FirebaseUser mCurrentUser;
    Spinner spinnerSelectBaby;
    String selectBaby;

    private FirebaseAuth mAuth;

    private SharedPreferences sharedPreferences;
    private String myProfilePrefrence="profilePrefrence";

    private String keyIsLoggedIn="isLoggedIn";
    private String keyFirstName="fName";
    private String keyPhone="phone";
    private String keyLastName="lName";
    private String keyEmail="email";
    private String keyUSerRole="userRole";
    private String keyPassword="password";

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors);


        mAuth = FirebaseAuth.getInstance();

        sharedPreferences=getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);


        rvDoctors =(RecyclerView) findViewById(R.id.rvDoctors);
        fabAddDoctors =(FloatingActionButton) findViewById(R.id.fabAddDoctors);

        fabAddDoctors.setVisibility(View.GONE);

        if(sharedPreferences.getString(keyUSerRole,"").equals("admin")){
            fabAddDoctors.setVisibility(View.VISIBLE);
        }


        fabAddDoctors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addDoctors();
            }
        });


        arrayList=new ArrayList<DoctorsDataProvider>();


                    progressDialog=new ProgressDialog(DoctorsActivity.this);
                    progressDialog.setMessage("Loading..");
                    progressDialog.setCancelable(false);
                    progressDialog.show();

                    callFirebase();





    }

    private void addDoctors() {

        final String[] babyCategory = new String[1];
        final android.app.AlertDialog.Builder alert=new android.app.AlertDialog.Builder(this);

        LayoutInflater inflater = getLayoutInflater();
        View alertLayout = inflater.inflate(R.layout.add_doctor, null);


        final EditText etDrName=(EditText) alertLayout.findViewById(R.id.etDrName);
        final EditText etDrEmail=(EditText) alertLayout.findViewById(R.id.etDrEmail);
        final EditText etDrPass=(EditText) alertLayout.findViewById(R.id.etDrPass);

        final EditText etDrPhone=(EditText) alertLayout.findViewById(R.id.etDrPhone);

        final EditText etClinicName=(EditText) alertLayout.findViewById(R.id.etClinicName);
        final EditText etClinicTiming=(EditText) alertLayout.findViewById(R.id.etClinicTiming);
        final EditText etClinicAddress=(EditText) alertLayout.findViewById(R.id.etClinicAddress);



        final Button btnAdd=(Button) alertLayout.findViewById(R.id.btnAddDoctor);



        alert.setCancelable(true);
        alert.setView(alertLayout);



        final android.app.AlertDialog alertDialog = alert.create();
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!etDrName.getText().toString().equals("") && !etDrEmail.getText().toString().equals("") && !etDrPass.getText().toString().equals("") && !etDrPhone.getText().toString().equals("") && !etClinicName.getText().toString().equals("") && !etClinicTiming.getText().toString().equals("") && !etClinicAddress.getText().toString().equals("")){


                    mAuth.createUserWithEmailAndPassword(etDrEmail.getText().toString(), etDrPass.getText().toString())
                            .addOnCompleteListener(DoctorsActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        // Sign in success, update UI with the signed-in user's information

                                        /*for sending verification email*/
                                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                                        if(user != null){
                                            user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if(task.isSuccessful()){
                                                        Toast.makeText(DoctorsActivity.this,"check email for verification",Toast.LENGTH_LONG).show();

                                                    }
                                                }
                                            });
                                        }

                                        String uId=user.getUid();
                                        // sending data to firebase

                                        database = FirebaseDatabase.getInstance().getReference().child("Users").child(uId);

                                        HashMap<String, String> userMap = new HashMap<>();
                                        userMap.put("firstName", etDrName.getText().toString());
                                        userMap.put("lastName", etDrName.getText().toString());
                                        userMap.put("email", etDrEmail.getText().toString());
                                        userMap.put("password", etDrPass.getText().toString());
                                        userMap.put("phone", etDrPhone.getText().toString());
                                        userMap.put("userRole", "Doctor");

                                        userMap.put("clinicName", etClinicName.getText().toString());
                                        userMap.put("clinicTiming", etClinicTiming.getText().toString());
                                        userMap.put("clinicAddress", etClinicAddress.getText().toString());

                                        database.setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    progressDialog.dismiss();
                                                    finish();
                                                }
                                            }
                                        });


                                        Toast.makeText(DoctorsActivity.this, "Doctor Added", Toast.LENGTH_SHORT).show();


                                    } else {
                                        progressDialog.dismiss();
                                        Toast.makeText(DoctorsActivity.this, "" + task.getException(), Toast.LENGTH_SHORT).show();

                                    }
                                }

                            });

                }

            }
        });
        alertDialog.show();

    }

    private void callFirebase() {
        database = FirebaseDatabase.getInstance().getReference().child("Users");
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                if (!dataSnapshot.exists()) {
                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(), "No Doctors Yet!", Toast.LENGTH_LONG).show();
                } else {
                    arrayList.clear();
                    progressDialog.dismiss();
                    mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
                    final String uId=mCurrentUser.getUid();

                    for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {



                            String id = childSnapshot.getKey();
                            String userRole=childSnapshot.child("userRole").getValue().toString();
                            if(userRole.equals("Doctor")){

                                String firstName=childSnapshot.child("firstName").getValue().toString();
                                String phone=childSnapshot.child("phone").getValue().toString();
                                String email=childSnapshot.child("email").getValue().toString();
                                String password=childSnapshot.child("password").getValue().toString();

                                String clinicName=childSnapshot.child("clinicName").getValue().toString();
                                String clinicAddress=childSnapshot.child("clinicAddress").getValue().toString();
                                String clinicTiming=childSnapshot.child("clinicTiming").getValue().toString();

                                arrayList.add(new DoctorsDataProvider( id,email,password,  firstName,  phone,  clinicName,  clinicAddress,  clinicTiming));

                            }








                    }

                  //  Collections.reverse(arrayList);

                    adapter = new DoctorsActivityAdapter(arrayList, getApplicationContext());
                    int numberOfColumns = 1;
                    LinearLayoutManager MyLayoutManager = new GridLayoutManager(getApplicationContext(), numberOfColumns);
                    rvDoctors.setLayoutManager(MyLayoutManager);
                    rvDoctors.setAdapter(adapter);


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });
    }
}
