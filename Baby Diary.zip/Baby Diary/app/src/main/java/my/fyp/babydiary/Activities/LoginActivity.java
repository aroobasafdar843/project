package my.fyp.babydiary.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import my.fyp.babydiary.R;

public class LoginActivity extends AppCompatActivity {

    TextView tvCreateAccount;
    EditText etEmail,etPass;
    Button btnLogin;
    private FirebaseAuth mAuth;
    private FirebaseUser mCurrentUser;
    private DatabaseReference mDatabase;

    ProgressDialog progressDialog;
    private SharedPreferences sharedPreferences;
    private String myProfilePrefrence="profilePrefrence";

    private String keyIsLoggedIn="isLoggedIn";
    private String keyFirstName="fName";
    private String keyPhone="phone";
    private String keyLastName="lName";
    private String keyEmail="email";
    private String keyUSerRole="userRole";
    private String keyPassword="password";

    private Boolean isLoggedIn;

    MainActivity mainActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        tvCreateAccount=(TextView) findViewById(R.id.tvCreateAccount);
        etEmail=(EditText) findViewById(R.id.etLoginEmail);
        etPass=(EditText) findViewById(R.id.etLoginPass);
        btnLogin=(Button) findViewById(R.id.btnLogin);
        progressDialog=new ProgressDialog(this);
        sharedPreferences=getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);

        boolean isLoggedIn=sharedPreferences.getBoolean(keyIsLoggedIn,false);

        if(isLoggedIn==true){
            startActivity(new Intent(LoginActivity.this,MainActivity.class));
            finish();
        }

        mAuth = FirebaseAuth.getInstance();
        etPass.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(etPass.getText().toString().length()<6){
                    etPass.setError("password minimum length is 6");
                }
            }
        });

        tvCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,SignupActivity.class));

            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etEmail.getText().toString().equals("") || etPass.getText().toString().equals("")){
                    Toast.makeText(LoginActivity.this,"Please Enter Email and Pass", Toast.LENGTH_LONG).show();
                }
                else {
                    String email,pass;
                    email=etEmail.getText().toString();
                    pass=etPass.getText().toString();
                    progressDialog.setTitle("Loging In");
                    progressDialog.setMessage("Please Wait");
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                    loginUser(email,pass);
                }
            }
        });



    }



    private void loginUser(String email, String pass) {

        mAuth.signInWithEmailAndPassword(email, pass)

                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information


                            // getting current user
                            mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
                            String uId=mCurrentUser.getUid();


                            if (!mCurrentUser.isEmailVerified()) {
                                Toast.makeText(LoginActivity.this, "Your Email is not verified", Toast.LENGTH_LONG).show();

                            } else {


                                // fetching users data from data base

                                mDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(uId);

                                mDatabase.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        progressDialog.dismiss();
                                        if (!dataSnapshot.exists()) {
                                            Toast.makeText(LoginActivity.this, "No Data", Toast.LENGTH_LONG).show();
                                        } else {
                                            String fname = dataSnapshot.child("firstName").getValue().toString();
                                            String lname = dataSnapshot.child("lastName").getValue().toString();
                                            String email = dataSnapshot.child("email").getValue().toString();
                                            String password = dataSnapshot.child("password").getValue().toString();
                                            String phone = dataSnapshot.child("phone").getValue().toString();
                                            String userRole = dataSnapshot.child("userRole").getValue().toString();

                                            // adding data in shared prefrence
                                            SharedPreferences.Editor editor = sharedPreferences.edit();
                                            editor.putBoolean(keyIsLoggedIn, true);
                                            editor.putString(keyFirstName, fname);
                                            editor.putString(keyLastName, lname);
                                            editor.putString(keyEmail, email);
                                            editor.putString(keyPassword, password);
                                            editor.putString(keyPhone, phone);
                                            editor.putString(keyUSerRole, userRole);
                                            editor.apply();

                                            startActivity(new Intent(LoginActivity.this, MainActivity.class));

                                        }


                                        finish();


                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });

                            }


                        } else {
                            // If sign in fails, display a message to the user.
                           progressDialog.dismiss();
                            Toast.makeText(LoginActivity.this, "Authentication failed."+task.getException(),
                                    Toast.LENGTH_SHORT).show();

                        }


                    }
                });

    }

}
