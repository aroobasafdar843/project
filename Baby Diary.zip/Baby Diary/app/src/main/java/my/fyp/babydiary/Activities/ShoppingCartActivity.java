package my.fyp.babydiary.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Random;

import my.fyp.babydiary.Adapters.ShoppingCartAdapter;
import my.fyp.babydiary.DataModel.ShoppingItem;
import my.fyp.babydiary.R;


public class ShoppingCartActivity extends AppCompatActivity {

    private final String TAG = ShoppingCartActivity.class.getSimpleName();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef;
    Boolean isCartEmpty = true;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private FirebaseUser user;
    String date, userID;
    int totalAmount = 0;
    String[] nextPlatform = null;
    String[] trainRoot = null;
    ArrayList<ShoppingItem> items;
    ListView listView;


    private SharedPreferences sharedPreferences;
    private String myProfilePrefrence = "profilePrefrence";
    private String keyIsLoggedIn = "isLoggedIn";
    private String keyUserName = "name";
    private String keyUserEmail = "email";
    private String keyUserPassword = "password";
    private String keyUserPhone = "phone";
    private String keyUserImage = "image";
    private String keyUserRole = "role";
    private String keyFirstName="fName";
    private Boolean isLoggedIn;

    public String rootNumber;


    protected Context context;
    String deliveryAddress;

    TextView tvTotalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_shopping_cart);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        sharedPreferences = getSharedPreferences(myProfilePrefrence, MODE_PRIVATE);

        tvTotalPrice=(TextView) findViewById(R.id.totalPriceCheckout);

        /* get Current Location */
        /*Intent n=getIntent();
        date=n.getStringExtra("date");*/
        items=new ArrayList<>();

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        items.clear();
        userID=currentUser.getUid();
                    myRef = database.getReference().child("CartItems").child(userID);

                    // adding value event listener for myRef
                    myRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {



                                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {


                                        items.add(new ShoppingItem(
                                                dataSnapshot1.getKey(),
                                                dataSnapshot1.child("productName").getValue().toString(),
                                                dataSnapshot1.child("productPrice").getValue().toString(),
                                                dataSnapshot1.child("productDesc").getValue().toString(),
                                                dataSnapshot1.child("productImage").getValue().toString(),
                                                dataSnapshot1.child("receiverName").getValue().toString(),
                                                dataSnapshot1.child("receiverPhone").getValue().toString(),
                                                dataSnapshot1.child("babyCategory").getValue().toString(),
                                                dataSnapshot1.child("garmentsCategory").getValue().toString()

                                        ));

                                    totalAmount += Integer.parseInt(dataSnapshot1.child("productPrice").getValue().toString());


                                }
                                listView = (ListView) findViewById(R.id.shoppingCartList);
                                // Now the Cart gets updated whenever the data changes in the server
                            final ShoppingCartAdapter adapter;
                            adapter=new ShoppingCartAdapter(getApplicationContext(), items);
                            listView.setAdapter(adapter);
                            adapter.notifyDataSetChanged();
                            tvTotalPrice.setText("Rs. "+totalAmount);

                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                                    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                                    String userID=currentUser.getUid();
                                    myRef = database.getReference().child("CartItems").child(userID).child(items.get(i).getProductID());

                                    myRef.removeValue(new DatabaseReference.CompletionListener() {
                                        @Override
                                        public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                            Intent intent = getIntent();
                                            finish();
                                            startActivity(intent);

                                            Toast.makeText(getApplicationContext(),"Removed Item",Toast.LENGTH_LONG).show();
                                            // ((Activity)context).finish();
                                        }
                                    });
                                }
                            });





                            }


                        @Override
                        public void onCancelled(DatabaseError error) {
                            Log.w(TAG, "Failed to read value.", error.toException());
                        }
                    });

        (findViewById(R.id.returnToPrevPage)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        (findViewById(R.id.checkOut)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               //

                EnterDeliveryAddress();
              //  orderProceed();
             //   finish();

            }
        });

        (findViewById(R.id.clearCart)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(findViewById(R.id.shoppingCartWindowLayout),
                        "Cleared!",
                        Snackbar.LENGTH_SHORT).show();
                clearCart();
                finish();
            }
        });

    }




    private void orderProceed(String deliveryAddress) {

        DateFormat df = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
        date = df.format(Calendar.getInstance().getTime());

        DateFormat df2 = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
        String date2 = df2.format(Calendar.getInstance().getTime());
        Random r = new Random();
        final int randomNumber = r.nextInt(1000);
        DatabaseReference myRefClear = null;
        HashMap<String, String> userMap = null;

        for (int i=0;i<items.size();i++) {

            myRefClear = FirebaseDatabase.getInstance().getReference("Orders").child(userID).child(date2).child(String.valueOf("item"+(i+1)));

            userMap = new HashMap<>();
            userMap.put("productID", items.get(i).getProductID());
            userMap.put("productName", items.get(i).getName());
            userMap.put("productPrice", items.get(i).getPrice());
            userMap.put("productDesc", items.get(i).getDescription());
            userMap.put("productImage", items.get(i).getProductImage());
            userMap.put("babyCategory", items.get(i).getBabyCategory());
            userMap.put("garmentsCategory", items.get(i).getGarmentsCategory());
            userMap.put("orderStatus", "Requested");
            userMap.put("receiverID", userID);
            userMap.put("dateTime", date2);
            userMap.put("orderNumber", String.valueOf(randomNumber));
            userMap.put("receiverName", sharedPreferences.getString(keyFirstName, null));
            userMap.put("receiverPhone", sharedPreferences.getString(keyUserPhone, null));
            userMap.put("receiverAddress", deliveryAddress);


            myRefClear.setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        clearCart();
                        finish();
                        Toast.makeText(getApplicationContext(), "Order Proceed", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                    }

                }
            });

        }



    }


    private void EnterDeliveryAddress() {

        final android.app.AlertDialog.Builder alert=new android.app.AlertDialog.Builder(this);




        LayoutInflater inflater = getLayoutInflater();
        View alertLayout = inflater.inflate(R.layout.select_delivery_address_layout, null);
        final EditText etDeliveryAddress=(EditText) alertLayout.findViewById(R.id.etDeliveryAddress);
        final TextView tvMessage=(TextView) alertLayout.findViewById(R.id.tvYourAddressMessage);

        tvMessage.setVisibility(View.GONE);

        Button btnProceedOrder=(Button) alertLayout.findViewById(R.id.btnProceedOrder);

        alert.setCancelable(true);
        alert.setView(alertLayout);


        final android.app.AlertDialog alertDialog = alert.create();


        btnProceedOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                if(!etDeliveryAddress.getText().toString().equals("")){

                    deliveryAddress=etDeliveryAddress.getText().toString();

                    orderProceed(deliveryAddress);

                } else {
                    Toast.makeText(getApplicationContext(),"Select Delivery Address",Toast.LENGTH_LONG).show();
                }



            }
        });

        alertDialog.show();
    }

    @Override
    public void onStart() {
        super.onStart();

    }

    @Override
    public void onStop() {
        super.onStop();

    }


    private void clearCart() {

            DatabaseReference myRefClear = FirebaseDatabase.getInstance().getReference("CartItems").child(userID);
            myRefClear.removeValue(new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                    Toast.makeText(getApplicationContext(),"Cart Clear",Toast.LENGTH_LONG).show();
                }
            });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }

        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


}
