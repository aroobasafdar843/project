package my.fyp.babydiary.DataModel;

public class ChatDataProvider {

    String message;
    String SenderName;
    String SenderID;
    String messageTime;

    public ChatDataProvider(String message, String senderName, String senderID, String messageTime) {
        this.message = message;
        SenderName = senderName;
        SenderID = senderID;
        this.messageTime = messageTime;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSenderName() {
        return SenderName;
    }

    public void setSenderName(String senderName) {
        SenderName = senderName;
    }

    public String getSenderID() {
        return SenderID;
    }

    public void setSenderID(String senderID) {
        SenderID = senderID;
    }

    public String getMessageTime() {
        return messageTime;
    }

    public void setMessageTime(String messageTime) {
        this.messageTime = messageTime;
    }
}
