package my.fyp.babydiary.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import my.fyp.babydiary.Adapters.GarmentsAdapter;
import my.fyp.babydiary.DataModel.GarmentsDataProvider;
import my.fyp.babydiary.R;

public class GarmentsActivity extends AppCompatActivity {

    private String myProfilePrefrence="profilePrefrence";
    private String keyUserCNIC ="cnicImage";
    private String keyIsLoggedIn="isLoggedIn";
    private String keyUserName="name";
    private String keyUserEmail="email";
    private String keyUserPassword="password";
    private String keyUserPhone="phone";
    private String keyUserImage="image";
    private String keyUserCity="city";
    private String keyUserAddress="address";
    private String keyUSerRole="userRole";
    private String keyAccountStatus="accountStatus";
    SharedPreferences sharedPreferences;
    private String keyFirstName="fName";
    RecyclerView recyclerView;
    private static final int CAMERA_REQEUST_CODE = 2000;
    DatabaseReference database;
    GarmentsAdapter adapter;
    ArrayList<GarmentsDataProvider> arrayList;
    String userRole;
    SearchView searchView;
    ProgressDialog progressDialog;
    FloatingActionButton fabAddnewProduct;
    private FirebaseUser mCurrentUser;
    String productImageURL;

    private FirebaseAuth mAuth;
    ImageView ivProductImage;
    FirebaseStorage storage;
    StorageReference storageRef;
    String babyCategory, garmentsCategory;

    private Uri ImageUri;
    ArrayList ImageList = new ArrayList();
    private int upload_count = 0;
    ArrayList urlStrings;

    Spinner spBabyCategory,spGarmentCategory;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_garments);

        setTitle("Garments");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        recyclerView=(RecyclerView) findViewById(R.id.rvGarmentsFregment);
        fabAddnewProduct=(FloatingActionButton) findViewById(R.id.fabAddToSell);
        spBabyCategory=(Spinner) findViewById(R.id.spinnerBabyCategory);
        spGarmentCategory=(Spinner) findViewById(R.id.spinnerGarmentsCategory);

        arrayList=new ArrayList<GarmentsDataProvider>();


        mAuth = FirebaseAuth.getInstance();
        storage = FirebaseStorage.getInstance();
        storageRef = storage.getReferenceFromUrl("gs://baby-diary-c446b.appspot.com");
        sharedPreferences=getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);

        userRole=sharedPreferences.getString(keyUSerRole,"");
        //getActivity().setTitle("Home "+userRole);
        fabAddnewProduct.setVisibility(View.GONE);

        if(userRole.equals("admin")){
            fabAddnewProduct.setVisibility(View.VISIBLE);
        }

        fabAddnewProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                addNewProduct();
            }


        });

        spBabyCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){

                }else {
                    babyCategory=spBabyCategory.getItemAtPosition(position).toString();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spGarmentCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){

                }else {
                    garmentsCategory=spGarmentCategory.getItemAtPosition(position).toString();

                    if(!babyCategory.equals("")){

                        progressDialog=new ProgressDialog(GarmentsActivity.this);
                        progressDialog.setMessage("Loading....");
                        progressDialog.show();

                        CallFirebase(babyCategory,garmentsCategory);
                    }else{
                        Toast.makeText(getApplicationContext(),"Select Baby Category First",Toast.LENGTH_LONG).show();
                    }

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



    }



    private void CallFirebase(final String babyCategory, final String garmentsCategory) {
        mCurrentUser=FirebaseAuth.getInstance().getCurrentUser();
        final String uId=mCurrentUser.getUid();


        database= FirebaseDatabase.getInstance().getReference().child("Products").child(babyCategory).child(garmentsCategory);

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                arrayList.clear();
                progressDialog.dismiss();

                if(!dataSnapshot.exists()){
                    //  Toast.makeText(getActivity(),"",Toast.LENGTH_LONG).show();
                }else {
                    for (DataSnapshot childSnapshot1 : dataSnapshot.getChildren()) {


                                    String addvertTime = childSnapshot1.getKey().toString();


                                    String productImage = childSnapshot1.child("productImage").getValue().toString();
                                    String productName = childSnapshot1.child("productName").getValue().toString();
                                    String productPrice=childSnapshot1.child("productPrice").getValue().toString();
                                    String productDesc = childSnapshot1.child("productDesc").getValue().toString();
                                    String receiverID = childSnapshot1.child("receiverID").getValue().toString();
                                    String receiverName = childSnapshot1.child("receiverName").getValue().toString();


                                    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                                    final String userID = currentUser.getUid();

                                        arrayList.add(new GarmentsDataProvider( addvertTime, productImage, babyCategory,garmentsCategory, productName,productPrice, productDesc, receiverID, receiverName));

                                }

                    adapter = new GarmentsAdapter(arrayList, GarmentsActivity.this);
                    int numberOfColumns = 2;
                    LinearLayoutManager MyLayoutManager = new GridLayoutManager(GarmentsActivity.this, numberOfColumns);
                    recyclerView.setLayoutManager(MyLayoutManager);
                    recyclerView.setAdapter(adapter);
                }

            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }



    private void addNewProduct() {

        final android.app.AlertDialog.Builder alert=new android.app.AlertDialog.Builder(GarmentsActivity.this);

        LayoutInflater inflater = getLayoutInflater();
        View alertLayout = inflater.inflate(R.layout.add_new_product_to_sale, null);
        ivProductImage=(ImageView) alertLayout.findViewById(R.id.ivProductImage);
        final EditText etProductName=(EditText) alertLayout.findViewById(R.id.etProductName);
        final EditText etProductPrice=(EditText) alertLayout.findViewById(R.id.etProductPrice);
        final EditText etProductDescription=(EditText) alertLayout.findViewById(R.id.etProductDescription);
        final Spinner spBabyCategory=(Spinner) alertLayout.findViewById(R.id.spinnerBabyCategory) ;
        final Spinner spinnerGarmentsCategory=(Spinner) alertLayout.findViewById(R.id.spinnerGarmentsCategory) ;

        final Button btnAdd=(Button) alertLayout.findViewById(R.id.btnAddAProduct);


        final ArrayList<String> subCategoryList=new ArrayList<>();
        spBabyCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    babyCategory ="";
                }
                else {
                    babyCategory =spBabyCategory.getItemAtPosition(position).toString();


                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });







        spinnerGarmentsCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    garmentsCategory ="";
                }
                else {

                    garmentsCategory =spinnerGarmentsCategory.getItemAtPosition(position).toString();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        alert.setCancelable(true);
        alert.setView(alertLayout);

        ivProductImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, CAMERA_REQEUST_CODE);
            }
        });



        final android.app.AlertDialog alertDialog = alert.create();
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if( !babyCategory.equals("") && !garmentsCategory.equals("") && !productImageURL.equals("") && !etProductName.getText().toString().equals("") && !etProductPrice.getText().toString().equals("") && !etProductDescription.getText().toString().equals("")){


                    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                    final String userID=currentUser.getUid();

                    DateFormat df = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
                    DateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
                    String date = df.format(Calendar.getInstance().getTime());
                    String date1 = df1.format(Calendar.getInstance().getTime());


                    database= FirebaseDatabase.getInstance().getReference().child("Products").child(babyCategory).child(garmentsCategory).child(date1);


                    HashMap<String,String> userMap=new HashMap<>();

                    userMap.put("productImage",productImageURL);
                    userMap.put("productName",etProductName.getText().toString());
                    userMap.put("productPrice",etProductPrice.getText().toString());
                    userMap.put("productDesc",etProductDescription.getText().toString());
                    userMap.put("receiverID","id");
                    userMap.put("receiverName","name");
                    userMap.put("isAvailable","true");


                    database.setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(GarmentsActivity.this,"New Product Added",Toast.LENGTH_LONG).show();
                            alertDialog.dismiss();
                        }
                    });

                }else {
                    Toast.makeText(GarmentsActivity.this,"Enter Correct Values",Toast.LENGTH_LONG).show();
                }

            }
        });
        alertDialog.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // if this is the result of our camera image request

        if (requestCode ==CAMERA_REQEUST_CODE ) {
            if (resultCode == RESULT_OK) {


                if (data.getClipData() != null) {

                    int countClipData = data.getClipData().getItemCount();
                    int currentImageSlect = 0;

                    while (currentImageSlect < countClipData) {

                        ImageUri = data.getClipData().getItemAt(currentImageSlect).getUri();
                        ImageList.add(ImageUri);
                        currentImageSlect = currentImageSlect + 1;
                    }
                    uploadImage();



                } else {
                    Toast.makeText(GarmentsActivity.this, "Please Select Multiple Images", Toast.LENGTH_SHORT).show();
                }

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void uploadImage() {
        urlStrings = new ArrayList<>();

        progressDialog=new ProgressDialog(GarmentsActivity.this);
        progressDialog.setMessage("Loading....");
        progressDialog.show();


        StorageReference ImageFolder = FirebaseStorage.getInstance().getReference().child("ImageFolder");

        for (upload_count = 0; upload_count < ImageList.size(); upload_count++) {

            Uri IndividualImage = (Uri) ImageList.get(upload_count);
            final StorageReference ImageName = ImageFolder.child("Images" + IndividualImage.getLastPathSegment());

            ImageName.putFile(IndividualImage).addOnSuccessListener(
                    new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            ImageName.getDownloadUrl().addOnSuccessListener(
                                    new OnSuccessListener<Uri>() {
                                        @Override
                                        public void onSuccess(Uri uri) {
                                            urlStrings.add(String.valueOf(uri));



                                            if (urlStrings.size() == ImageList.size()){
                                                storeLink(urlStrings);
                                            }

                                        }
                                    }
                            );
                        }
                    }
            );


        }
    }

    private void storeLink(ArrayList<String> urlStrings) {

        HashMap<String, String> hashMap = new HashMap<>();

        for (int i = 0; i <urlStrings.size() ; i++) {
            hashMap.put("ImgLink"+i, urlStrings.get(i));

        }
        DateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
        final String date1 = df1.format(Calendar.getInstance().getTime());
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Product Images").child(date1);

        databaseReference.setValue(hashMap)
                .addOnCompleteListener(
                        new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    productImageURL=date1;
                                    Toast.makeText(GarmentsActivity.this, "Successfully Uploaded", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                ).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(GarmentsActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
        progressDialog.dismiss();


        ImageList.clear();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_shopping_cart, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;

            case R.id.viewShoppingCart:
                startActivity(new Intent(getApplicationContext(),ShoppingCartActivity.class));
                break;

        }

        return super.onOptionsItemSelected(menuItem);
    }
}