package my.fyp.babydiary.DataModel;

public class SingleOrderViewModel {

    String receiverName;
    String receiverPhone;
    String receiverAddress;
    String receiverID;
    String orderTime;
    String orderNumber;
    String orderStatus;
    String productName;
    String productPrice;
    String productImage;
    String productDesc;
    String productID;
    String OrderStatus;
    String babyCategory;
    String garmentsCategory;

    public SingleOrderViewModel(String receiverName, String receiverPhone, String receiverAddress, String receiverID, String orderTime, String orderNumber, String orderStatus, String productName, String productPrice, String productImage, String productDesc, String productID, String orderStatus1, String babyCategory, String garmentsCategory) {
        this.receiverName = receiverName;
        this.receiverPhone = receiverPhone;
        this.receiverAddress = receiverAddress;
        this.receiverID = receiverID;
        this.orderTime = orderTime;
        this.orderNumber = orderNumber;
        this.orderStatus = orderStatus;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productImage = productImage;
        this.productDesc = productDesc;
        this.productID = productID;
        OrderStatus = orderStatus1;
        this.babyCategory = babyCategory;
        this.garmentsCategory = garmentsCategory;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getReceiverPhone() {
        return receiverPhone;
    }

    public void setReceiverPhone(String receiverPhone) {
        this.receiverPhone = receiverPhone;
    }

    public String getReceiverAddress() {
        return receiverAddress;
    }

    public void setReceiverAddress(String receiverAddress) {
        this.receiverAddress = receiverAddress;
    }

    public String getReceiverID() {
        return receiverID;
    }

    public void setReceiverID(String receiverID) {
        this.receiverID = receiverID;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getBabyCategory() {
        return babyCategory;
    }

    public void setBabyCategory(String babyCategory) {
        this.babyCategory = babyCategory;
    }

    public String getGarmentsCategory() {
        return garmentsCategory;
    }

    public void setGarmentsCategory(String garmentsCategory) {
        this.garmentsCategory = garmentsCategory;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }
}
