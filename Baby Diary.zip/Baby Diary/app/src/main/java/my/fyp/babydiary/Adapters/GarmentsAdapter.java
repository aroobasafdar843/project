package my.fyp.babydiary.Adapters;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.squareup.picasso.Picasso;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import my.fyp.babydiary.DataModel.GarmentsDataProvider;
import my.fyp.babydiary.R;


public class GarmentsAdapter extends RecyclerView.Adapter<GarmentsAdapter.RecyclerViewHolder>  {
    Context ctx;
    ArrayList<GarmentsDataProvider> arrayList = new ArrayList<GarmentsDataProvider>();
    ArrayList<String> productImagesList = new ArrayList<>();
    RecyclerViewHolder recyclerViewHolder;
    private String myProfilePrefrence="profilePrefrence";
    private String keyUSerRole="userRole";
    private String keyUserName="name";
    private String keyFirstName="fName";
    private String keyUserEmail="email";
    private String keyUserPassword="password";
    private String keyUserImage="image";
    private String keyUserPhone="phone";
    SharedPreferences sharedPreferences;
    private GestureDetector mGestureDetector;

    String userRole;
    DatabaseReference database;

    public GarmentsAdapter(ArrayList<GarmentsDataProvider> arrayList, Context ctx){

        this.arrayList=arrayList;
        this.ctx=ctx;

    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.garments_singleitem, parent, false);

        recyclerViewHolder = new RecyclerViewHolder(view,ctx);

        sharedPreferences=ctx.getSharedPreferences(myProfilePrefrence,MODE_PRIVATE);
        userRole=sharedPreferences.getString(keyUSerRole,"");

        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(final RecyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.tvEditPost.setVisibility(View.GONE);
        holder.tvDeletePost.setVisibility(View.GONE);
        holder.ivAddToCart.setVisibility(View.VISIBLE);

        holder.ivAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                String uId=currentUser.getUid();
                // DateFormat df = new SimpleDateFormat("dd MMM yyyy HH:mm");


                database= FirebaseDatabase.getInstance().getReference().child("CartItems").child(uId).child(arrayList.get(position).getAdvertTime());


                HashMap<String, String> userMap = new HashMap<>();
                userMap.put("productName", arrayList.get(position).getProductName());
                userMap.put("productPrice", arrayList.get(position).getProductPrice());
                userMap.put("productDesc", arrayList.get(position).getProductDescription());
                userMap.put("productImage",arrayList.get(position).getProductImage());
                userMap.put("babyCategory",arrayList.get(position).getBabyCategory());
                userMap.put("garmentsCategory",arrayList.get(position).getGarmentsCategory());

                userMap.put("receiverName",sharedPreferences.getString(keyFirstName,null));
                userMap.put("receiverPhone",sharedPreferences.getString(keyUserPhone,null));


                database.setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(ctx.getApplicationContext(), "Item added To cart",Toast.LENGTH_LONG).show();
                        }
                        else {
                            Toast.makeText(ctx.getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
                        }

                    }
                });

            }
        });
        if(userRole.equals("admin")){
            holder.ivAddToCart.setVisibility(View.GONE);
            holder.tvEditPost.setVisibility(View.VISIBLE);
            holder.tvDeletePost.setVisibility(View.VISIBLE);
        }
        database= FirebaseDatabase.getInstance().getReference().child("Product Images").child(arrayList.get(position).getProductImage());

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                productImagesList.clear();
                for (DataSnapshot childSnapshot1 : snapshot.getChildren()) {

                    String url=childSnapshot1.getValue().toString();
                    productImagesList.add(url);
                    //      Toast.makeText(ctx,"url"+url,Toast.LENGTH_LONG).show();
                }
                for (int i=0;i<productImagesList.size();i++){
                    ImageView imageView=new ImageView(ctx);

                    Picasso.with(ctx).load(productImagesList.get(i)).placeholder(R.drawable.iconaddproduct100).into(imageView);
                    // imageView.setScaleType(ImageView.ScaleType.FIT_XY);
                    holder.ivProductImageSell.addView(imageView);
                    holder.ivProductImageSell.setFlipInterval(3000);
                    holder.ivProductImageSell.setAutoStart(true);
                    holder.ivProductImageSell.setInAnimation(ctx,android.R.anim.slide_in_left);
                    holder.ivProductImageSell.setOutAnimation(ctx,android.R.anim.slide_out_right);
                    holder.ivProductImageSell.startFlipping();


                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });


        holder.tvProductDesc.setText(arrayList.get(position).getProductDescription());
        holder.tvProductName.setText(arrayList.get(position).getProductName());



        holder.tvDeletePost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder alertbox = new AlertDialog.Builder(v.getRootView().getContext());

                alertbox.setTitle("Warning");
                alertbox.setMessage("Do You Want To Remove This Product");
                final AlertDialog alertDialog = alertbox.create();
                alertbox.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        deletePost(arrayList.get(position).getBabyCategory(),arrayList.get(position).getGarmentsCategory(),arrayList.get(position).getAdvertTime());
                        alertDialog.dismiss();
                    }
                });

                alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                alertbox.show();
            }
        });

        holder.tvEditPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog.Builder alert=new AlertDialog.Builder(ctx);

                LayoutInflater inflater = LayoutInflater.from(ctx);

                View alertLayout = inflater.inflate(R.layout.edit_postlayout, null);

                final EditText etProductName=(EditText) alertLayout.findViewById(R.id.etUpdateProductName);
                final EditText etProductDescription=(EditText) alertLayout.findViewById(R.id.etUpdateProductDescription);

                final Button btnAdd=(Button) alertLayout.findViewById(R.id.btnUpdateProduct);

                etProductName.setText(arrayList.get(position).getProductName());
                etProductDescription.setText(arrayList.get(position).getProductDescription());


                alert.setCancelable(true);
                alert.setView(alertLayout);




                final AlertDialog alertDialog = alert.create();
                btnAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if(!etProductName.getText().toString().equals("")  && !etProductDescription.getText().toString().equals("")){


                            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                            final String userID=currentUser.getUid();

                            DateFormat df = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
                            DateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
                            String date = df.format(Calendar.getInstance().getTime());
                            String date1 = df1.format(Calendar.getInstance().getTime());


                            database= FirebaseDatabase.getInstance().getReference().child("Products").child(arrayList.get(position).getBabyCategory()).child(arrayList.get(position).getGarmentsCategory()).child(arrayList.get(position).getAdvertTime());

                            HashMap<String,Object> userMap=new HashMap<>();

                            userMap.put("productName",etProductName.getText().toString());
                            userMap.put("productDesc",etProductDescription.getText().toString());

                            //  database.push().setValue(userMap);

                            database.updateChildren(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    Toast.makeText(ctx,"Product Updated",Toast.LENGTH_LONG).show();
                                    alertDialog.dismiss();
                                }
                            });

                        }

                    }
                });
                alertDialog.show();
            }
        });



    }

    private void deletePost(String productCategory,String productSubCategory, String advtTime) {

        database= FirebaseDatabase.getInstance().getReference().child("Products").child(productCategory).child(productSubCategory).child(advtTime);

        database.removeValue(new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {


                Toast.makeText(ctx,"Product Removed",Toast.LENGTH_LONG).show();
            }
        });
    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }



    public static class RecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView tvProductName, tvProductDesc,tvDeletePost,tvEditPost;
        ImageView ivAddToCart;

        Context ctx;
        ConstraintLayout constLayoutSingleClassItem;
        ViewFlipper ivProductImageSell;
        @SuppressLint("NewApi")
        public RecyclerViewHolder(View view, Context ctx) {
            super(view);
            view.setOnClickListener(this);
            this.ctx=ctx;


            tvProductName =(TextView) view.findViewById(R.id.tvProductName);
            tvProductDesc =(TextView) view.findViewById(R.id.tvProductDetails);
            ivProductImageSell =(ViewFlipper) view.findViewById(R.id.ivProductImageSell);
            tvDeletePost=(TextView) view.findViewById(R.id.tvDeletePost);
            tvEditPost=(TextView) view.findViewById(R.id.tvEditPost);
            ivAddToCart=(ImageView) view.findViewById(R.id.ivAddToCart);

            constLayoutSingleClassItem=(ConstraintLayout) view.findViewById(R.id.constLayoutSingleClassItem);

        }

        @Override
        public void onClick(View view) {








        }
    }

}

